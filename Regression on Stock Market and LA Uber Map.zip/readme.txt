Project is set up in Google Colab. Please change the directory of dataset to your own.

